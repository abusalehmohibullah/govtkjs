<template>
    <div class="grid gap-1 grid-cols-2 grid-rows-2 sm:gap-4 sm:grid-cols-4 sm:grid-rows-1 mt-5">
                <div class="card m-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Class Routine</h5>
                    </div>
                </div>
                <div class="card m-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Curriculum</h5>
                    </div>
                </div>
                <div class="card m-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Sections Info</h5>
                    </div>
                </div>
                <div class="card m-0">
                    <div class="card-body">
                        <h5 class="card-title text-center">Students Info</h5>
                    </div>
                </div>

            </div>
</template>