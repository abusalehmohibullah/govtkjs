<template>
        <div class="grid gap-1 grid-cols-2 grid-rows-2 sm:gap-10 sm:grid-cols-4 sm:grid-rows-1 my-5">
        <div class="card m-0">
            <div class="card-body bg-gradient-to-b from-cyan-500 to-blue-500 rounded">
                <h5 class="text-center text-xl text-white">Student's Portal</h5>
            </div>
        </div>
        <div class="card m-0">
            <div class="card-body bg-gradient-to-b from-cyan-500 to-blue-500 rounded">
                <h5 class="text-center text-xl text-white">Admission</h5>
            </div>
        </div>
        <div class="card m-0">
            <div class="card-body bg-gradient-to-b from-cyan-500 to-blue-500 rounded">
                <h5 class="text-center text-xl text-white">Result</h5>
            </div>
        </div>
        <div class="card m-0">
            <div class="card-body bg-gradient-to-b from-cyan-500 to-blue-500 rounded">
                <h5 class="text-center text-xl text-white">Contact</h5>
            </div>
        </div>

    </div>
</template>