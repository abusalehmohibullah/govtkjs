<script setup>
defineProps({
    infos : Object,
});
</script>

<template>
    <div >
        <div class="sm:flex mt-6 bg-white">
            <div class="sm:w-1/3">
                <img src="https://th.bing.com/th/id/OIP.JMLFs6GMSEJQNZ64p1D4BQHaE8?pid=ImgDet&rs=1"
                    class="card-img-top" alt="...">
            </div>
            <div class="sm:w-2/3 p-5">
                <h5 class="card-title">{{ infos.message_1_title }}</h5>
                <div>{{ infos.message_1_content }}</div>

            </div>
        </div>
        <div v-if="infos.message_2_content !== null" class="sm:flex mt-6 bg-white">
            
            <div class="sm:w-1/3">
                <img src="https://th.bing.com/th/id/OIP.JMLFs6GMSEJQNZ64p1D4BQHaE8?pid=ImgDet&rs=1"
                    class="card-img-top" alt="...">
            </div>
            <div class="sm:w-2/3 p-5 sm:order-first">
                <h5 class="card-title">{{ infos.message_2_title }}</h5>
                <div>{{ infos.message_2_content }}</div>

            </div>
        </div>
    </div>
</template>