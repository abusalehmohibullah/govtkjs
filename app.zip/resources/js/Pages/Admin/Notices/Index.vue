  
<script setup>

import { Link } from '@inertiajs/vue3';
import AdminLayout from '@/Layouts/AdminLayout.vue';

import NoticeTable from '@/Pages/Admin/Notices/Partials/NoticeTable.vue';
import Header from '@/Components/Header.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import Pagination from '@/Components/Pagination.vue';

const { notices } = defineProps(['notices']);

</script>

<template>
    <AdminLayout title="Basic Info">

        <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">

            <Header>
                <template #header>
                    Notices
                </template>
                <template #description>
                    Lorem ipsumuasi eniumquam error aspernatsuscipit.
                </template>
                <template #aside>
                    <Link :href="route('admin.notices.create')">
                    <PrimaryButton>
                        Create
                    </PrimaryButton>
                    </Link>
                </template>
            </Header>

            <NoticeTable :notices="notices" />
            
            <!-- <template>
                <div>
                    <template v-for="link in notices.links">
                        <Link v-if="link.url" :href="link.url">
                        <PrimaryButton v-if="link.active" v-html="link.label" />
                        <SecondaryButton v-else class="text-slate-600" v-html="link.label" />
                        </Link>
                        <SecondaryButton v-else v-html="link.label" class="opacity-50" />
                    </template>
                </div>
            </template> -->
        </div>

    </AdminLayout>
</template>

  