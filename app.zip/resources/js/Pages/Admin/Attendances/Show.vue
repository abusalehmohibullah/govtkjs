  
<script setup>

import AdminLayout from '@/Layouts/AdminLayout.vue';

import ShowStudentTable from '@/Pages/Admin/Students/Partials/ShowStudentTable.vue';

const { student, classroom } = defineProps(['student', 'classroom']);

</script>

<template>
    <AdminLayout title="Show Student">
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Show Student
            </h2>
        </template>

        <div>

            <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
                <!-- Use the Form component to wrap your form -->
                <ShowStudentTable :student="student" :classroom="classroom"/>
            </div>


        </div>
    </AdminLayout>
</template>

  