<script setup>

import GeneralLayout from '@/Layouts/GeneralLayout.vue';
import { computed } from 'vue';

</script>

<template>
    <GeneralLayout>
        <div class="container p-5">
            <div class="mb-3 py-2 animate-on-scroll" data-animation="fadeIn">
                <div class="shadow-sm bg-white pt-2 rounded">
                    <div class="font-bold text-3xl text-center p-2">Results</div>
                    <div class="bg-white text-center text-xl mt-10">
                        Will be available soon
                    </div>
                </div>
            </div>
        </div>
    </GeneralLayout>
</template>

