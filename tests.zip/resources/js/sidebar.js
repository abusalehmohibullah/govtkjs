// Your sidebar toggle logic here
// export function toggleSidebar() {
//     const sidebar = document.querySelector('.sidebar');
//     if (sidebar) {
//         sidebar.classList.toggle('hidden'); // Toggle a CSS class to show/hide the sidebar
//     }
// }
