declare module 'vue-pagination-2' {
    const VuePagination: any;
    export default VuePagination;
  }
  