<template>
    <div class="grid gap-10 grid-cols-3 grid-rows-1 my-5">

    <div class="card m-0">
        <div class="card-body bg-gradient-to-r from-cyan-300 to-blue-300">
            <h5 class="text-slate-600 text-center">Address</h5>
            <h3 class="text-center text-black">Rajoir, Madaripur.</h3>
        </div>
    </div>
    <div class="card m-0">
        <div class="card-body bg-gradient-to-r from-cyan-300 to-blue-300">
            <h5 class="text-slate-600 text-center">Contact</h5>
            <h3 class="text-center text-black">01716682779</h3>
        </div>
    </div>
    <div class="card m-0">
        <div class="card-body bg-gradient-to-r from-cyan-300 to-blue-300">
            <h5 class="text-slate-600 text-center">Email</h5>
            <h3 class="text-center text-black">kjs_institution@yahoo.com</h3>
        </div>
    </div>

</div>
</template>