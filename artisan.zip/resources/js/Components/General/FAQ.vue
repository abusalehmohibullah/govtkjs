<template>

    <div class="shadow-sm bg-white mb-3 py-2">
        <div class="accordion accordion-flush" id="faqs-accordion">
            <div class="h2 p-2 deep-color large-text">Frequently Asked Questions</div>
            <hr class="m-0">

            <div class="accordion-item animate-on-scroll" data-animation="fadeInDown">
                <h2 class="accordion-header" id="flush-heading">
                    <button class="accordion-button collapsed mini-text" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse1" aria-expanded="false" aria-controls="flush-collapse">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </button>
                </h2>
                <div id="flush-collapse1" class="accordion-collapse collapse bg-light" aria-labelledby="flush-heading" data-bs-parent="#faqs-accordion">
                    <div class="accordion-body mini-text">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, quod. Commodi quia optio officia voluptatem, velit obcaecati quam assumenda esse natus cum a expedita similique, consectetur, provident aperiam! Ullam, vitae! ex recusandae obcaecati dolorem soluta iste. Libero quisquam recusandae, expedita, nesciunt quibusdam voluptatum molestias a quo obcaecati id deleniti ad! Esse.</div>
                </div>
            </div>
            <div class="accordion-item animate-on-scroll" data-animation="fadeInDown">
                <h2 class="accordion-header" id="flush-heading">
                    <button class="accordion-button collapsed mini-text" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse2" aria-expanded="false" aria-controls="flush-collapse">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </button>
                </h2>
                <div id="flush-collapse2" class="accordion-collapse collapse bg-light" aria-labelledby="flush-heading" data-bs-parent="#faqs-accordion">
                    <div class="accordion-body mini-text">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, quod. Commodi quia optio officia voluptatem, velit obcaecati quam assumenda esse natus cum a expedita similique, consectetur, provident aperiam! Ullam, vitae! ex recusandae obcaecati dolorem soluta iste. Libero quisquam recusandae, expedita, nesciunt quibusdam voluptatum molestias a quo obcaecati id deleniti ad! Esse.</div>
                </div>
            </div>
            <div class="accordion-item animate-on-scroll" data-animation="fadeInDown">
                <h2 class="accordion-header" id="flush-heading">
                    <button class="accordion-button collapsed mini-text" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse3" aria-expanded="false" aria-controls="flush-collapse">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </button>
                </h2>
                <div id="flush-collapse3" class="accordion-collapse collapse bg-light" aria-labelledby="flush-heading" data-bs-parent="#faqs-accordion">
                    <div class="accordion-body mini-text">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, quod. Commodi quia optio officia voluptatem, velit obcaecati quam assumenda esse natus cum a expedita similique, consectetur, provident aperiam! Ullam, vitae! ex recusandae obcaecati dolorem soluta iste. Libero quisquam recusandae, expedita, nesciunt quibusdam voluptatum molestias a quo obcaecati id deleniti ad! Esse.</div>
                </div>
            </div>
            <div class="accordion-item animate-on-scroll" data-animation="fadeInDown">
                <h2 class="accordion-header" id="flush-heading">
                    <button class="accordion-button collapsed mini-text" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse4" aria-expanded="false" aria-controls="flush-collapse">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </button>
                </h2>
                <div id="flush-collapse4" class="accordion-collapse collapse bg-light" aria-labelledby="flush-heading" data-bs-parent="#faqs-accordion">
                    <div class="accordion-body mini-text">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, quod. Commodi quia optio officia voluptatem, velit obcaecati quam assumenda esse natus cum a expedita similique, consectetur, provident aperiam! Ullam, vitae! ex recusandae obcaecati dolorem soluta iste. Libero quisquam recusandae, expedita, nesciunt quibusdam voluptatum molestias a quo obcaecati id deleniti ad! Esse.</div>
                </div>
            </div>

        </div>
    </div>


</template>