<template>
    <div class="grid gap-4 grid-cols-2 grid-rows-1 mt-4">
        <div class="card m-0">
            <div class="card-body">
                <h5 class="card-title">Permitted for teching on
                </h5>
                <h3>January 01, 1929</h3>
            </div>
        </div>
        <!-- <div class="card m-0">
            <div class="card-body">
                <h5 class="card-title">Recognition</h5>
            </div>
        </div> -->
        <!-- <div class="card m-0">
            <div class="card-body">
                <h5 class="card-title">MPO-fication Info</h5>
            </div>
        </div> -->
        <div class="card m-0">
            <div class="card-body">
                <h5 class="card-title">Nationalized on</h5>
                <h3>May 21, 2018</h3>
            </div>
        </div>

    </div>

</template>