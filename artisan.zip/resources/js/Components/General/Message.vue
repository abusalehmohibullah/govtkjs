<template>
    <div >
        <div class="flex mt-6 bg-white">
            <div class="w-1/3">
                <img src="https://th.bing.com/th/id/OIP.JMLFs6GMSEJQNZ64p1D4BQHaE8?pid=ImgDet&rs=1"
                    class="card-img-top" alt="...">
            </div>
            <div class="w-2/3 p-5">
                <h5 class="card-title">Card title</h5>
                <div>This is a wider card with supporting text below as a natural lead-in to additional
                    content. This content is a little bit longer. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis delectus dolores distinctio perspiciatis quaerat laboriosam dolore ex sapiente consequuntur ducimus exercitationem beatae quam nam, neque, voluptatibus totam corporis dolorem aspernatur. Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere, molestias! Dolor, blanditiis officia! Nisi unde voluptate aliquid adipisci voluptas quas repellendus deserunt, tenetur quae libero laborum aut ab illum. Quam?</div>

            </div>
        </div>
        <div class="flex mt-6 bg-white">
            
            <div class="w-2/3 p-5">
                <h5 class="card-title">Card title</h5>
                <div>This card has supporting text below as a natural lead-in to additional content. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, ex illo! Inventore ipsa ipsum fuga omnis nam sint, saepe cumque excepturi dolorum modi, corrupti commodi eaque! Fugit architecto quo animi. Lorem ipsum dolor sit amet consectetur adipisicing elit. Non similique numquam amet neque repellendus reiciendis animi porro. Repellat, iusto eos dolorum distinctio eius, veniam nam voluptatem cumque, magni consectetur velit.</div>

            </div>
            <div class="w-1/3">
                <img src="https://th.bing.com/th/id/OIP.JMLFs6GMSEJQNZ64p1D4BQHaE8?pid=ImgDet&rs=1"
                    class="card-img-top" alt="...">
            </div>
        </div>
    </div>
</template>